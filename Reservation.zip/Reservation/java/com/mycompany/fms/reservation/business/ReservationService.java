package com.mycompany.fms.reservation.business;

import com.mycompany.fms.reservation.helper.ReservationInfo;
import com.mycompany.fms.reservation.persistence.ReservationCRUD;

public class ReservationService {

    public ReservationInfo reserve(int flightId, int userId) {
        return ReservationCRUD.createReservation(flightId, userId);
    }
}