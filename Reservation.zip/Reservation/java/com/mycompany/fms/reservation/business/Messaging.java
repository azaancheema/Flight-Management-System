package com.mycompany.fms.reservation.business;

import io.kubemq.sdk.basic.ServerAddressNotSuppliedException;
import io.kubemq.sdk.event.Channel;
import io.kubemq.sdk.event.Event;
import io.kubemq.sdk.tools.Converter;

import javax.net.ssl.SSLException;
import java.io.IOException;

public class Messaging {

    private Messaging() {
    }

    public static void sendMessage(String message) throws IOException {

        String channelName = "reservation_channel";
        String clientID = "reservation-service-publisher";

        String kubeMQAddress = "kubemq-cluster-grpc.kubemq.svc.cluster.local:50000";

        System.out.println("kubeMQAddress = " + kubeMQAddress);

        Channel channel = new Channel(channelName, clientID, false, kubeMQAddress);
        channel.setStore(true);

        Event event = new Event();
        event.setBody(Converter.ToByteArray(message));
        event.setEventId("reservation-event");

        try {
            channel.SendEvent(event);
            System.out.println("Message sent: " + message);
        } catch (SSLException e) {
            e.printStackTrace();
        } catch (ServerAddressNotSuppliedException e) {
            e.printStackTrace();
        }
    }
}