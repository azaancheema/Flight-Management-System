package com.mycompany.fms.reservation.endpoint;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("webresources")
public class ApplicationConfig extends ResourceConfig {

    public ApplicationConfig() {
        packages("com.mycompany.fms.reservation.endpoint");
    }
}