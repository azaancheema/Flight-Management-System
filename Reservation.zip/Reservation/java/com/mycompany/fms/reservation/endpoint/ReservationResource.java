package com.mycompany.fms.reservation.endpoint;

import com.mycompany.fms.reservation.business.ReservationService;
import com.mycompany.fms.reservation.helper.ReservationInfo;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("reservations")
public class ReservationResource {

    private final ReservationService service = new ReservationService();

    @POST
    @Path("create")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public Response createReservation(ReservationInfo req) {

        if (req == null || req.getFlightId() <= 0 || req.getUserId() <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("<error>Invalid reservation. Need flightId and userId.</error>")
                    .build();
        }

        ReservationInfo created = service.reserve(req.getFlightId(), req.getUserId());

        if (created == null) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("<error>Reservation failed.</error>")
                    .build();
        }

        return Response.ok(created).build();
    }
}