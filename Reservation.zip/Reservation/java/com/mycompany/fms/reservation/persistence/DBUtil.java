package com.mycompany.fms.reservation.persistence;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

    private DBUtil() {
    }

    public static Connection getCon() {
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String dbHost = System.getenv("RESERVE_DB_HOST");
            if (dbHost == null || dbHost.trim().isEmpty()) {
                dbHost = "localhost";
            }

            String url = "jdbc:mysql://" + dbHost + ":3306/RESERVE_FMS"
                    + "?autoReconnect=true&useSSL=false&serverTimezone=America/Toronto";

            con = DriverManager.getConnection(url, "root", "student");
            System.out.println("ReservationService DB connection successful.");
        } catch (Exception e) {
            System.out.println("ReservationService DB connection failed.");
            e.printStackTrace();
        }

        return con;
    }
}