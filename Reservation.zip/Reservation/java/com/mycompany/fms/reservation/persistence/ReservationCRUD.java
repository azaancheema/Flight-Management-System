package com.mycompany.fms.reservation.persistence;

import com.mycompany.fms.reservation.business.Messaging;
import com.mycompany.fms.reservation.helper.ReservationInfo;

import java.sql.*;

public class ReservationCRUD {

    private ReservationCRUD() {}

    public static ReservationInfo createReservation(int flightId, int userId) {

        String countSql = "SELECT COUNT(*) AS total FROM Reservations WHERE flight_id = ?";
        String duplicateSql = "SELECT reservation_id FROM Reservations WHERE flight_id = ? AND user_id = ?";
        String insertSql = "INSERT INTO Reservations (user_id, flight_id, confirmation_status, payment_status) VALUES (?, ?, ?, ?)";

        try (Connection con = DBUtil.getCon()) {

            // 1. Count reservations
            int count = 0;
            try (PreparedStatement ps = con.prepareStatement(countSql)) {
                ps.setInt(1, flightId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) count = rs.getInt("total");
            }

            if (count >= 5) {
                System.out.println("Flight fully booked (5/5)");
                return null;
            }

            // 2. Prevent same user duplicate
            try (PreparedStatement ps = con.prepareStatement(duplicateSql)) {
                ps.setInt(1, flightId);
                ps.setInt(2, userId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    System.out.println("User already reserved this flight");
                    return null;
                }
            }

            // 3. Insert reservation
            try (PreparedStatement ps = con.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {

                ps.setInt(1, userId);
                ps.setInt(2, flightId);
                ps.setString(3, "Successful");
                ps.setString(4, "Paid by Card");

                ps.executeUpdate();

                ResultSet keys = ps.getGeneratedKeys();
                keys.next();

                ReservationInfo r = new ReservationInfo();
                r.setReservationId(keys.getInt(1));
                r.setFlightId(flightId);
                r.setUserId(userId);
                r.setConfirmationStatus("Successful");
                r.setPaymentStatus("Paid by Card");

                // 4. Send async message
                String msg = "RESERVE:" + flightId + ":" + userId + ":Successful:Paid by Card";
                Messaging.sendMessage(msg);

                return r;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}