package com.mycompany.fms.search.helper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "flights")
public class FlightsXML implements Serializable {

    private List<FlightInfo> flights = new ArrayList<>();

    public FlightsXML() {
    }

    public FlightsXML(List<FlightInfo> flights) {
        this.flights = flights;
    }

    @XmlElement(name = "flight")
    public List<FlightInfo> getFlights() {
        return flights;
    }

    public void setFlights(List<FlightInfo> flights) {
        this.flights = flights;
    }
}
