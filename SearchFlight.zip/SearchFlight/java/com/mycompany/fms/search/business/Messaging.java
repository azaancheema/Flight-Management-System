package com.mycompany.fms.search.business;

import com.mycompany.fms.search.persistence.FlightCRUD;
import io.grpc.stub.StreamObserver;
import io.kubemq.sdk.event.EventReceive;
import io.kubemq.sdk.event.Subscriber;
import io.kubemq.sdk.subscription.EventsStoreType;
import io.kubemq.sdk.subscription.SubscribeRequest;
import io.kubemq.sdk.subscription.SubscribeType;
import io.kubemq.sdk.tools.Converter;

public class Messaging {

    private Messaging() {
    }

    public static void receivingEventsStore(String channelName) throws Exception {

        String kubeMQAddress = "kubemq-cluster-grpc.kubemq.svc.cluster.local:50000";

        System.out.println("kubeMQAddress = " + kubeMQAddress);

        String clientID = "search-flights-" + System.currentTimeMillis();

        Subscriber subscriber = new Subscriber(kubeMQAddress);
        SubscribeRequest subscribeRequest = new SubscribeRequest();

        subscribeRequest.setChannel(channelName);
        subscribeRequest.setClientID(clientID);

        subscribeRequest.setSubscribeType(SubscribeType.EventsStore);
        subscribeRequest.setEventsStoreType(EventsStoreType.StartAtSequence);
        subscribeRequest.setEventsStoreTypeValue(1);

        System.out.println("About to subscribe to channel: " + channelName);
        System.out.println("SubscribeType = EventsStore, StartAtSequence = 1");

        subscriber.SubscribeToEvents(subscribeRequest, new StreamObserver<EventReceive>() {

            @Override
            public void onNext(EventReceive ev) {
                try {
                    String msg = String.valueOf(Converter.FromByteArray(ev.getBody()));
                    System.out.println("Received: " + msg);

                    String[] p = msg.split(":");

                    if (p.length == 5 && "RESERVE".equals(p[0])) {
                        int flightId = Integer.parseInt(p[1]);
                        int userId = Integer.parseInt(p[2]);
                        String confirmationStatus = p[3];
                        String paymentStatus = p[4];

                        System.out.println("Parsed flightId = " + flightId + ", userId = " + userId);

                        boolean saved = FlightCRUD.saveFlightReservation(
                                flightId, userId, confirmationStatus, paymentStatus
                        );

                        System.out.println("saveFlightReservation result = " + saved);
                    } else {
                        System.out.println("Message format invalid.");
                    }

                } catch (Exception e) {
                    System.out.println("Error processing message.");
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(Throwable t) {
                System.out.println("Subscriber error:");
                t.printStackTrace();
            }

            @Override
            public void onCompleted() {
                System.out.println("Subscription completed.");
            }
        });

        System.out.println("Subscriber connected and waiting for messages...");
    }
}