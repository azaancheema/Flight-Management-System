package com.mycompany.fms.search.business;

import com.mycompany.fms.search.helper.FlightInfo;
import com.mycompany.fms.search.persistence.FlightCRUD;

import java.util.List;

public class FlightService {

    public List<FlightInfo> searchFlights(String airline, String date,
                                          String departure, String destination) {
        return FlightCRUD.searchFlights(airline, date, departure, destination);
    }

    public FlightInfo getFlightById(int flightId) {
        return FlightCRUD.getFlightById(flightId);
    }
}