package com.mycompany.fms.search.endpoint;

import com.mycompany.fms.search.business.FlightService;
import com.mycompany.fms.search.helper.FlightInfo;
import com.mycompany.fms.search.helper.FlightsXML;

import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("flights")
public class FlightResource {

    private final FlightService flightService = new FlightService();

    @GET
    @Path("search")
    @Produces(MediaType.APPLICATION_XML)
    public FlightsXML searchFlights(@QueryParam("airline") String airline,
                                    @QueryParam("date") String date,
                                    @QueryParam("departure") String departure,
                                    @QueryParam("destination") String destination) {

        List<FlightInfo> flights = flightService.searchFlights(airline, date, departure, destination);
        return new FlightsXML(flights);
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_XML)
    public Response getFlightById(@PathParam("id") int id) {
        FlightInfo flight = flightService.getFlightById(id);

        if (flight == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        return Response.ok(flight).build();
    }
}