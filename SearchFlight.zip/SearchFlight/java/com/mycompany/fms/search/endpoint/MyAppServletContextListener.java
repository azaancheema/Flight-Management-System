package com.mycompany.fms.search.endpoint;

import com.mycompany.fms.search.business.Messaging;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

public class MyAppServletContextListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("SearchFlightsService listener starting...");

        Runnable r = new Runnable() {
            @Override
            public void run() {
                try {
                    Messaging.receivingEventsStore("reservation_channel");
                } catch (Exception e) {
                    System.out.println("ERROR starting subscriber:");
                    e.printStackTrace();
                }
            }
        };

        new Thread(r).start();
        System.out.println("SearchFlightsService listener started.");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("SearchFlightsService stopped.");
    }
}