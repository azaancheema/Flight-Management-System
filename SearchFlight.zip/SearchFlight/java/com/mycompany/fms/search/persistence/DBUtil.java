package com.mycompany.fms.search.persistence;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

    private DBUtil() {
    }

    public static Connection getCon() {
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String dbHost = System.getenv("SEARCH_DB_HOST");
            if (dbHost == null || dbHost.trim().isEmpty()) {
                dbHost = "localhost";
            }

            String url = "jdbc:mysql://" + dbHost + ":3306/SEARCH_FMS"
                    + "?autoReconnect=true&useSSL=false&serverTimezone=America/Toronto";

            con = DriverManager.getConnection(url, "root", "student");
            System.out.println("SearchFlightsService DB connection successful.");
        } catch (Exception e) {
            System.out.println("SearchFlightsService DB connection failed.");
            e.printStackTrace();
        }

        return con;
    }
}