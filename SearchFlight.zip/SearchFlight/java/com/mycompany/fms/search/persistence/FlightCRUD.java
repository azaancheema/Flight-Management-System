package com.mycompany.fms.search.persistence;

import com.mycompany.fms.search.helper.FlightInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FlightCRUD {

    private FlightCRUD() {}

    public static List<FlightInfo> searchFlights(String airline, String date,
                                                 String departure, String destination) {

        List<FlightInfo> flights = new ArrayList<FlightInfo>();

        String sql = "SELECT flight_id, airline, departure_location, arrival_location, " +
                     "availability_status, stops, time, date " +
                     "FROM Flights " +
                     "WHERE airline = ? AND date = ? AND departure_location = ? AND arrival_location = ?";

        try (Connection con = DBUtil.getCon();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, airline);
            ps.setString(2, date);
            ps.setString(3, departure);
            ps.setString(4, destination);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int flightId = rs.getInt("flight_id");

                    FlightInfo f = new FlightInfo();
                    f.setFlightId(flightId);
                    f.setAirline(rs.getString("airline"));
                    f.setDepartureLocation(rs.getString("departure_location"));
                    f.setArrivalLocation(rs.getString("arrival_location"));
                    f.setStops(rs.getInt("stops"));
                    f.setTime(rs.getString("time"));
                    f.setDate(rs.getString("date"));

                    int count = getReservationCount(flightId);

                    if (count == 0) {
                        f.setAvailabilityStatus("Available");
                    } else if (count < 5) {
                        f.setAvailabilityStatus("Reserved (" + count + "/5)");
                    } else {
                        f.setAvailabilityStatus("Fully Booked (5/5)");
                    }

                    flights.add(f);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return flights;
    }

    public static FlightInfo getFlightById(int flightId) {
        FlightInfo f = null;

        String sql = "SELECT flight_id, airline, departure_location, arrival_location, " +
                     "availability_status, stops, time, date " +
                     "FROM Flights WHERE flight_id = ?";

        try (Connection con = DBUtil.getCon();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, flightId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    f = new FlightInfo();
                    f.setFlightId(rs.getInt("flight_id"));
                    f.setAirline(rs.getString("airline"));
                    f.setDepartureLocation(rs.getString("departure_location"));
                    f.setArrivalLocation(rs.getString("arrival_location"));
                    f.setStops(rs.getInt("stops"));
                    f.setTime(rs.getString("time"));
                    f.setDate(rs.getString("date"));

                    int count = getReservationCount(flightId);

                    if (count == 0) {
                        f.setAvailabilityStatus("Available");
                    } else if (count < 5) {
                        f.setAvailabilityStatus("Reserved (" + count + "/5)");
                    } else {
                        f.setAvailabilityStatus("Fully Booked (5/5)");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    public static int getReservationCount(int flightId) {
        String sql = "SELECT COUNT(*) FROM FlightReservations WHERE flight_id = ?";

        try (Connection con = DBUtil.getCon();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, flightId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public static boolean saveFlightReservation(int flightId, int userId,
                                                String confirmationStatus, String paymentStatus) {

        String duplicateSql = "SELECT id FROM FlightReservations WHERE flight_id = ? AND user_id = ? LIMIT 1";
        String insertSql = "INSERT INTO FlightReservations (flight_id, user_id, confirmation_status, payment_status) VALUES (?, ?, ?, ?)";

        try (Connection con = DBUtil.getCon();
             PreparedStatement dupPs = con.prepareStatement(duplicateSql)) {

            dupPs.setInt(1, flightId);
            dupPs.setInt(2, userId);

            try (ResultSet rs = dupPs.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Reservation already exists in SearchFlightsService for flight "
                            + flightId + " and user " + userId);
                    return true;
                }
            }

            try (PreparedStatement ps = con.prepareStatement(insertSql)) {
                ps.setInt(1, flightId);
                ps.setInt(2, userId);
                ps.setString(3, confirmationStatus);
                ps.setString(4, paymentStatus);

                return ps.executeUpdate() > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}