<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.mycompany.fms.frontend.helper.ReservationInfo"%>
<%@page import="com.mycompany.fms.frontend.helper.FlightInfo"%>
<%@page import="com.mycompany.fms.frontend.helper.UserInfo"%>
<%
    ReservationInfo r = (ReservationInfo) request.getAttribute("reservation");
    FlightInfo f = (FlightInfo) request.getAttribute("flight");
    UserInfo user = (UserInfo) request.getAttribute("user");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Reservation Successful</title>

    <style>
        body{
            background:#dae5f5;
            font-family:Arial, sans-serif;
            text-align:center;
            padding-top:70px;
            margin:0;
        }

        .card{
            background:white;
            width:600px;
            max-width:90%;
            margin:0 auto;
            padding:35px;
            border-radius:12px;
            box-shadow:0 4px 12px rgba(0,0,0,0.12);
        }

        h1{
            color:#1f7a1f;
            margin-top:0;
        }

        .info{
            text-align:left;
            margin-top:20px;
            line-height:1.9;
            font-size:16px;
        }

        .links{
            margin-top:25px;
        }

        .links a{
            color:#1f4f8c;
            text-decoration:none;
            font-weight:bold;
            margin:0 10px;
        }

        .links a:hover{
            text-decoration:underline;
        }
    </style>
</head>
<body>

    <div class="card">
        <h1>Reservation Successful ✅</h1>

        <div class="info">
            <p><b>User:</b> <%= (user != null ? user.getName() : "N/A") %></p>
            <p><b>Email:</b> <%= (user != null ? user.getEmail() : "N/A") %></p>
            <hr>

            <p><b>Reservation ID:</b> <%= (r != null ? r.getReservationId() : "N/A") %></p>
            <p><b>User ID:</b> <%= (r != null ? r.getUserId() : "N/A") %></p>
            <p><b>Flight ID:</b> <%= (f != null ? f.getFlightId() : "N/A") %></p>
            <p><b>Airline:</b> <%= (f != null ? f.getAirline() : "N/A") %></p>
            <p><b>Departure:</b> <%= (f != null ? f.getDepartureLocation() : "N/A") %></p>
            <p><b>Arrival:</b> <%= (f != null ? f.getArrivalLocation() : "N/A") %></p>
            <p><b>Availability:</b> <%= (f != null ? f.getAvailabilityStatus() : "N/A") %></p>
            <p><b>Stops:</b> <%= (f != null ? f.getStops() : "N/A") %></p>
            <p><b>Date:</b> <%= (f != null ? f.getDate() : "N/A") %></p>
            <p><b>Time:</b> <%= (f != null ? f.getTime() : "N/A") %></p>
            <p><b>Confirmation Status:</b> <%= (r != null ? r.getConfirmationStatus() : "N/A") %></p>
            <p><b>Payment Status:</b> <%= (r != null ? r.getPaymentStatus() : "N/A") %></p>
        </div>

        <div class="links">
            <a href="flightOptions">Back to Options</a>
            <a href="SearchFlights">Search More Flights</a>
            <a href="logout">Logout</a>
        </div>
    </div>

</body>
</html>