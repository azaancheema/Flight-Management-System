<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Flight Management System - Login</title>

    <style>
        body{
            background:#dae5f5;
            color:black;
            font-family:Arial, sans-serif;
            display:flex;
            justify-content:center;
            align-items:center;
            min-height:100vh;
            flex-direction:column;
            text-align:center;
            margin:0;
            padding:20px;
            box-sizing:border-box;
        }

        .main-title{
            font-size:36px;
            font-weight:bold;
            margin-bottom:10px;
        }

        .image-container{
            margin:10px 0 20px 0;
        }

        .image-container img{
            width:420px;
            max-width:100%;
            height:auto;
            border-radius:10px;
            box-shadow:0 4px 12px rgba(0,0,0,0.15);
        }

        .login-title{
            font-size:24px;
            margin-bottom:20px;
            font-weight:bold;
        }

        form{
            background:white;
            padding:25px 30px;
            border-radius:12px;
            box-shadow:0 4px 12px rgba(0,0,0,0.12);
            min-width:320px;
        }

        .field-label{
            display:block;
            text-align:left;
            margin-bottom:6px;
            font-weight:bold;
        }

        input{
            padding:10px;
            width:100%;
            box-sizing:border-box;
            margin-bottom:18px;
            border:1px solid #b7c7de;
            border-radius:6px;
            font-size:15px;
        }

        .button{
            background:#72a2e6;
            color:white;
            padding:12px 28px;
            font-size:18px;
            cursor:pointer;
            border:none;
            border-radius:6px;
            width:100%;
        }

        .button:hover{
            background:#3372cc;
        }

        .error-message{
            color:red;
            margin-top:15px;
            font-weight:bold;
        }
    </style>
</head>
<body>

    <div class="main-title">Flight Management System</div>

    <div class="image-container">
        <img src="resources/flight.jpg" alt="Flight Image">
    </div>

    <div class="login-title">Login</div>

    <form action="login" method="POST">
        <label class="field-label" for="email">Email</label>
        <input type="text" id="email" name="email" required>

        <label class="field-label" for="password">Password</label>
        <input type="password" id="password" name="password" required>

        <button class="button" type="submit">Login</button>
    </form>

    <p class="error-message">
        <%= request.getAttribute("loginError") != null
                ? request.getAttribute("loginError")
                : "" %>
    </p>

</body>
</html>