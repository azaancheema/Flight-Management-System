<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.mycompany.fms.frontend.helper.FlightInfo"%>
<%
    List<FlightInfo> flights = (List<FlightInfo>) request.getAttribute("flights");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Flight Results</title>

    <style>
        body{
            background:#dae5f5;
            font-family:Arial, sans-serif;
            text-align:center;
            padding:40px 20px;
            margin:0;
        }

        table{
            margin:0 auto;
            border-collapse:collapse;
            width:95%;
            max-width:1100px;
            background:white;
        }

        th, td{
            border:1px solid #ccc;
            padding:12px;
            text-align:center;
        }

        th{
            background:#72a2e6;
            color:white;
        }

        .button{
            background:#72a2e6;
            color:white;
            padding:8px 14px;
            border:none;
            cursor:pointer;
            border-radius:4px;
        }

        .cannot-reserve{
            color:red;
            font-weight:bold;
        }
    </style>
</head>
<body>

    <h1>Flight Search Results</h1>

    <%
        if (flights == null || flights.isEmpty()) {
    %>
        <p><b>No flights found.</b></p>
    <%
        } else {
    %>
        <table>
            <tr>
                <th>ID</th>
                <th>Airline</th>
                <th>Departure</th>
                <th>Arrival</th>
                <th>Availability</th>
                <th>Stops</th>
                <th>Date</th>
                <th>Time</th>
                <th>Reserve</th>
            </tr>

            <%
                for (FlightInfo f : flights) {
            %>
            <tr>
                <td><%= f.getFlightId() %></td>
                <td><%= f.getAirline() %></td>
                <td><%= f.getDepartureLocation() %></td>
                <td><%= f.getArrivalLocation() %></td>
                <td><%= f.getAvailabilityStatus() %></td>
                <td><%= f.getStops() %></td>
                <td><%= f.getDate() %></td>
                <td><%= f.getTime() %></td>
                <td>
                    <%
                        if ("SOLD_OUT".equalsIgnoreCase(f.getAvailabilityStatus())) {
                    %>
                        <span class="cannot-reserve">Cannot Reserve</span>
                    <%
                        } else {
                    %>
                        <form action="ReserveFlight" method="POST" style="margin:0;">
                            <input type="hidden" name="flightId" value="<%= f.getFlightId() %>"/>
                            <button class="button" type="submit">Reserve</button>
                        </form>
                    <%
                        }
                    %>
                </td>
            </tr>
            <%
                }
            %>
        </table>
    <%
        }
    %>

</body>
</html>