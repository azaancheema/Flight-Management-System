<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.mycompany.fms.frontend.helper.UserInfo"%>
<%
    UserInfo user = (UserInfo) session.getAttribute("user");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Flight Options</title>

    <style>
        body{
            background:#dae5f5;
            font-family:Arial, sans-serif;
            text-align:center;
            padding-top:80px;
            margin:0;
        }

        .container{
            background:white;
            width:500px;
            max-width:90%;
            margin:0 auto;
            padding:35px;
            border-radius:12px;
            box-shadow:0 4px 12px rgba(0,0,0,0.12);
        }

        h1{
            margin-bottom:10px;
        }

        .subtitle{
            color:#555;
            margin-bottom:25px;
        }

        .button{
            background:#72a2e6;
            color:white;
            padding:15px 32px;
            font-size:18px;
            margin:10px;
            border:none;
            cursor:pointer;
            border-radius:6px;
            min-width:180px;
        }

        .button:hover{
            background:#3372cc;
        }

        .logout{
            margin-top:25px;
            display:inline-block;
            color:#1f4f8c;
            text-decoration:none;
            font-weight:bold;
        }

        .logout:hover{
            text-decoration:underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Welcome, <%= (user != null ? user.getName() : "User") %>!</h1>

        <div>
            <button class="button" onclick="window.location.href='SearchFlights'">
                Search / Reserve Flight
            </button>
        </div>

        <div>
           <button class="button" type="button" onclick="alert('No Reservations Found')">
                Cancel Flight
            </button>
        </div>

        <a class="logout" href="<%= request.getContextPath() %>/login">Logout</a>
    </div>

</body>
</html>
