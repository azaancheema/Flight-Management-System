<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.mycompany.fms.frontend.helper.UserInfo"%>
<%
    UserInfo user = (UserInfo) session.getAttribute("user");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Search Flights</title>

    <style>
        body{
            background:#dae5f5;
            color:black;
            font-family:Arial, sans-serif;
            display:flex;
            justify-content:center;
            align-items:center;
            min-height:100vh;
            margin:0;
            padding:20px;
            box-sizing:border-box;
        }

        .card{
            background:white;
            padding:30px;
            width:450px;
            max-width:100%;
            border-radius:12px;
            box-shadow:0 4px 12px rgba(0,0,0,0.12);
        }

        h1{
            text-align:center;
            margin-top:0;
        }

        .welcome{
            text-align:center;
            margin-bottom:20px;
            color:#555;
        }

        label{
            display:block;
            margin-bottom:6px;
            font-weight:bold;
        }

        input{
            width:100%;
            box-sizing:border-box;
            padding:10px;
            margin-bottom:16px;
            border:1px solid #b7c7de;
            border-radius:6px;
            font-size:15px;
        }

        .button{
            background:#72a2e6;
            color:white;
            padding:12px 20px;
            font-size:17px;
            width:100%;
            cursor:pointer;
            border:none;
            border-radius:6px;
        }

        .button:hover{
            background:#3372cc;
        }

        .links{
            text-align:center;
            margin-top:18px;
        }

        .links a{
            color:#1f4f8c;
            text-decoration:none;
            font-weight:bold;
            margin:0 10px;
        }

        .links a:hover{
            text-decoration:underline;
        }
    </style>
</head>
<body>

    <div class="card">
        <h1>Search for Flights</h1>

        <form action="SearchFlights" method="POST">
            <label for="airline">Airline</label>
            <input type="text" id="airline" name="airline" required>

            <label for="date">Date</label>
            <input type="date" id="date" name="date" required>

            <label for="departure">Departure</label>
            <input type="text" id="departure" name="departure" required>

            <label for="destination">Destination</label>
            <input type="text" id="destination" name="destination" required>

            <button class="button" type="submit">Search Flights</button>
        </form>

        <div class="links">
            <a href="flightOptions">Back to Options</a>
            <a href="logout">Logout</a>
        </div>
    </div>

</body>
</html>