<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Error</title>

    <style>
        body{
            background:#dae5f5;
            font-family:Arial, sans-serif;
            text-align:center;
            padding-top:80px;
            margin:0;
        }

        .card{
            background:white;
            width:500px;
            max-width:90%;
            margin:0 auto;
            padding:35px;
            border-radius:12px;
            box-shadow:0 4px 12px rgba(0,0,0,0.12);
        }

        h1{
            color:#b00020;
            margin-top:0;
        }

        .msg{
            color:#b00020;
            font-weight:bold;
            margin-top:15px;
            word-wrap:break-word;
        }

        .links{
            margin-top:25px;
        }

        .links a{
            color:#1f4f8c;
            text-decoration:none;
            font-weight:bold;
            margin:0 10px;
        }

        .links a:hover{
            text-decoration:underline;
        }
    </style>
</head>
<body>

    <div class="card">
        <h1>Something went wrong</h1>

        <p class="msg">
            <%= request.getAttribute("errorMessage") != null
                    ? request.getAttribute("errorMessage")
                    : "Unknown error." %>
        </p>

        <div class="links">
            <a href="login">Go to Login</a>
            <a href="flightOptions">Flight Options</a>
            <a href="SearchFlights">Search Flights</a>
        </div>
    </div>

</body>
</html>