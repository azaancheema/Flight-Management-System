package com.mycompany.fms.frontend.servlet;

import com.mycompany.fms.frontend.client.ReservationServiceClient;
import com.mycompany.fms.frontend.client.SearchServiceClient;
import com.mycompany.fms.frontend.helper.FlightInfo;
import com.mycompany.fms.frontend.helper.ReservationInfo;
import com.mycompany.fms.frontend.helper.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "ReserveFlightServlet", urlPatterns = {"/ReserveFlight"})
public class ReserveFlightServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        UserInfo user = (UserInfo) session.getAttribute("user");

        try {
            int flightId = Integer.parseInt(request.getParameter("flightId"));

            FlightInfo flight = SearchServiceClient.getFlightById(flightId);
            if (flight == null) {
                request.setAttribute("errorMessage", "Flight not found.");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }

            ReservationInfo reservation =
                    ReservationServiceClient.reserveFlight(flightId, user.getUserId());

            if (reservation == null) {
                request.setAttribute("errorMessage", "Reservation failed.");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }

            request.setAttribute("user", user);
            request.setAttribute("flight", flight);
            request.setAttribute("reservation", reservation);

            request.getRequestDispatcher("/reserveSuccess.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid flight ID.");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Reserve failed: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}