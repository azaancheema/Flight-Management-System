package com.mycompany.fms.frontend.persistence;

import com.mycompany.fms.frontend.helper.UserInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserCRUD {

    private UserCRUD() {
    }

    public static UserInfo readByEmailAndPassword(String email, String password) {
        UserInfo user = null;

        String sql = "SELECT user_id, name, email, password FROM Users WHERE email = ?";

        try (Connection con = DBUtil.getCon();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }

                String dbPass = rs.getString("password");

                if (dbPass != null && dbPass.equals(password)) {
                    user = new UserInfo(
                            rs.getInt("user_id"),
                            rs.getString("name"),
                            rs.getString("email")
                    );
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
}