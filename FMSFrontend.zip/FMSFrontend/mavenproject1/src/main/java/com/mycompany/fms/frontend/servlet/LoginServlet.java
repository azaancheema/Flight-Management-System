package com.mycompany.fms.frontend.servlet;

import com.mycompany.fms.frontend.auth.AuthService;
import com.mycompany.fms.frontend.auth.JWTUtil;
import com.mycompany.fms.frontend.helper.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    private static final String AUTH_COOKIE_NAME = "fms_token";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        UserInfo user = AuthService.login(email, password);

        if (user == null) {
            request.setAttribute("loginError", "Invalid email or password.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        String token = JWTUtil.generateToken(user);

        HttpSession session = request.getSession(true);
        session.setAttribute("user", user);
        session.setAttribute("token", token);

        Cookie authCookie = new Cookie(AUTH_COOKIE_NAME, token);
        authCookie.setHttpOnly(true);
        authCookie.setPath(request.getContextPath().isEmpty() ? "/" : request.getContextPath());
        response.addCookie(authCookie);

        response.sendRedirect(request.getContextPath() + "/flightOptions");
    }
}