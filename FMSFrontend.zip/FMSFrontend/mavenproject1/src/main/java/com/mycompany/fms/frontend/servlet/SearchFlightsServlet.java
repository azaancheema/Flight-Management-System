package com.mycompany.fms.frontend.servlet;

import com.mycompany.fms.frontend.client.SearchServiceClient;
import com.mycompany.fms.frontend.helper.FlightInfo;
import com.mycompany.fms.frontend.helper.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "SearchFlightsServlet", urlPatterns = {"/SearchFlights"})
public class SearchFlightsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session != null) {
            UserInfo user = (UserInfo) session.getAttribute("user");
            if (user != null) {
                request.setAttribute("user", user);
            }
        }

        request.getRequestDispatcher("/searchFlights.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String airline = request.getParameter("airline");
        String date = request.getParameter("date");
        String departure = request.getParameter("departure");
        String destination = request.getParameter("destination");

        try {
            List<FlightInfo> flights = SearchServiceClient.searchFlights(
                    airline,
                    date,
                    departure,
                    destination
            );

            HttpSession session = request.getSession(false);
            if (session != null) {
                UserInfo user = (UserInfo) session.getAttribute("user");
                if (user != null) {
                    request.setAttribute("user", user);
                }
            }

            request.setAttribute("flights", flights);
            request.setAttribute("airline", airline);
            request.setAttribute("date", date);
            request.setAttribute("departure", departure);
            request.setAttribute("destination", destination);

            request.getRequestDispatcher("/flightResults.jsp").forward(request, response);

        } catch (Exception e) {
            request.setAttribute("errorMessage", "Search failed: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}