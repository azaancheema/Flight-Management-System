package com.mycompany.fms.frontend.auth;

import com.mycompany.fms.frontend.helper.UserInfo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import javax.crypto.spec.SecretKeySpec;

public class JWTUtil {

   
    private static final String SECRET = "fms_lab4_super_secret_key_2026_change_this";
    private static final SignatureAlgorithm SIGNATURE_ALGORITHM = SignatureAlgorithm.HS256;

    // 30 minutes
    private static final long EXPIRATION_MS = 30L * 60L * 1000L;

    private JWTUtil() {
        
    }

    private static Key getSigningKey() {
        byte[] secretBytes = SECRET.getBytes(StandardCharsets.UTF_8);
        return new SecretKeySpec(secretBytes, SIGNATURE_ALGORITHM.getJcaName());
    }

    /**
     * Generates JWT using UserInfo.
     */
    public static String generateToken(UserInfo user) {
        if (user == null) {
            return null;
        }

        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);
        Date expiry = new Date(nowMillis + EXPIRATION_MS);

        JwtBuilder builder = Jwts.builder()
                .setIssuedAt(now)
                .setIssuer("FMSFrontend")
                .setSubject(user.getEmail())
                .claim("userId", user.getUserId())
                .claim("name", user.getName())
                .claim("email", user.getEmail())
                .setExpiration(expiry)
                .signWith(getSigningKey());

        return builder.compact();
    }


    public static boolean isValidToken(String token) {
        try {
            Claims claims = getAllClaims(token);
            return claims != null && !isExpired(claims);
        } catch (Exception e) {
            return false;
        }
    }

    
    public static String getEmail(String token) {
        try {
            Claims claims = getAllClaims(token);
            return claims.getSubject();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Returns user id from token claim.
     */
    public static Integer getUserId(String token) {
        try {
            Claims claims = getAllClaims(token);
            Object value = claims.get("userId");

            if (value instanceof Integer) {
                return (Integer) value;
            }

            if (value instanceof Number) {
                return ((Number) value).intValue();
            }

            if (value != null) {
                return Integer.parseInt(value.toString());
            }

            return null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Returns user name from token claim.
     */
    public static String getName(String token) {
        try {
            Claims claims = getAllClaims(token);
            Object value = claims.get("name");
            return value != null ? value.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Returns all claims if token is valid.
     */
    public static Claims getAllClaims(String token) throws JwtException {
        if (token == null || token.trim().isEmpty()) {
            return null;
        }

        Jws<Claims> parsed = Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token);

        return parsed.getBody();
    }

    private static boolean isExpired(Claims claims) {
        Date expiration = claims.getExpiration();
        return expiration == null || expiration.before(new Date());
    }
}