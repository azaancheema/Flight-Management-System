package com.mycompany.fms.frontend.client;

import com.mycompany.fms.frontend.helper.FlightInfo;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class SearchServiceClient {

    private SearchServiceClient() {
    }

    private static String getBaseUrl() {
        String serviceHost = System.getenv("SEARCH_SERVICE_HOST");
        if (serviceHost == null || serviceHost.trim().isEmpty()) {
            serviceHost = "localhost:8080";
        }

        return "http://" + serviceHost + "/SearchFlightsService/webresources/flights";
    }

    public static List<FlightInfo> searchFlights(String airline,
                                                 String date,
                                                 String departure,
                                                 String destination) throws Exception {

        StringBuilder urlBuilder = new StringBuilder(getBaseUrl()).append("/search?");

        boolean first = true;

        if (airline != null && !airline.trim().isEmpty()) {
            urlBuilder.append("airline=").append(encode(airline));
            first = false;
        }

        if (date != null && !date.trim().isEmpty()) {
            if (!first) {
                urlBuilder.append("&");
            }
            urlBuilder.append("date=").append(encode(date));
            first = false;
        }

        if (departure != null && !departure.trim().isEmpty()) {
            if (!first) {
                urlBuilder.append("&");
            }
            urlBuilder.append("departure=").append(encode(departure));
            first = false;
        }

        if (destination != null && !destination.trim().isEmpty()) {
            if (!first) {
                urlBuilder.append("&");
            }
            urlBuilder.append("destination=").append(encode(destination));
        }

        HttpURLConnection connection = null;
        InputStream inputStream = null;

        try {
            URL url = new URL(urlBuilder.toString());
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/xml");

            int responseCode = connection.getResponseCode();

            if (responseCode != HttpURLConnection.HTTP_OK) {
                String error = readErrorResponse(connection);
                throw new Exception("Search service failed. HTTP " + responseCode + " - " + error);
            }

            inputStream = connection.getInputStream();
            return parseFlightsXml(inputStream);

        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    public static FlightInfo getFlightById(int flightId) throws Exception {
        HttpURLConnection connection = null;
        InputStream inputStream = null;

        try {
            URL url = new URL(getBaseUrl() + "/" + flightId);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/xml");

            int responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                return null;
            }

            if (responseCode != HttpURLConnection.HTTP_OK) {
                String error = readErrorResponse(connection);
                throw new Exception("Get flight failed. HTTP " + responseCode + " - " + error);
            }

            inputStream = connection.getInputStream();
            return parseSingleFlightXml(inputStream);

        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private static String encode(String value) throws Exception {
        return URLEncoder.encode(value, "UTF-8");
    }

    private static String readErrorResponse(HttpURLConnection connection) {
        try {
            InputStream errorStream = connection.getErrorStream();
            if (errorStream == null) {
                return "No error details";
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(errorStream));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            reader.close();
            return sb.toString();

        } catch (Exception e) {
            return "Unable to read error response";
        }
    }

    private static List<FlightInfo> parseFlightsXml(InputStream inputStream) throws Exception {
        List<FlightInfo> flights = new ArrayList<>();

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(inputStream);

        document.getDocumentElement().normalize();

        NodeList flightNodes = document.getElementsByTagName("flight");

        for (int i = 0; i < flightNodes.getLength(); i++) {
            Node node = flightNodes.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                flights.add(buildFlightFromElement(element));
            }
        }

        return flights;
    }

    private static FlightInfo parseSingleFlightXml(InputStream inputStream) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(inputStream);

        document.getDocumentElement().normalize();

        NodeList flightNodes = document.getElementsByTagName("flight");

        if (flightNodes.getLength() > 0) {
            Element element = (Element) flightNodes.item(0);
            return buildFlightFromElement(element);
        }

        Element root = document.getDocumentElement();
        if (root != null && "flight".equalsIgnoreCase(root.getTagName())) {
            return buildFlightFromElement(root);
        }

        return null;
    }

    private static FlightInfo buildFlightFromElement(Element element) {
        FlightInfo flight = new FlightInfo();

        flight.setFlightId(parseInt(getTagValue(element, "flightId")));
        flight.setAirline(getTagValue(element, "airline"));
        flight.setDepartureLocation(getTagValue(element, "departureLocation"));
        flight.setArrivalLocation(getTagValue(element, "arrivalLocation"));
        flight.setAvailabilityStatus(getTagValue(element, "availabilityStatus"));
        flight.setStops(parseInt(getTagValue(element, "stops")));
        flight.setTime(getTagValue(element, "time"));
        flight.setDate(getTagValue(element, "date"));

        return flight;
    }

    private static String getTagValue(Element parent, String tagName) {
        NodeList nodeList = parent.getElementsByTagName(tagName);

        if (nodeList == null || nodeList.getLength() == 0) {
            return "";
        }

        Node node = nodeList.item(0);
        if (node == null) {
            return "";
        }

        return node.getTextContent() != null ? node.getTextContent().trim() : "";
    }

    private static int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }
}