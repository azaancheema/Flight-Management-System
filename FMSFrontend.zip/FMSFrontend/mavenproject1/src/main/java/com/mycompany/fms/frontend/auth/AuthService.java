package com.mycompany.fms.frontend.auth;

import com.mycompany.fms.frontend.helper.UserInfo;
import com.mycompany.fms.frontend.persistence.UserCRUD;

public class AuthService {

    private AuthService() {
    }

    public static UserInfo login(String email, String password) {
        if (email == null || password == null) {
            return null;
        }

        email = email.trim();

        if (email.isEmpty() || password.trim().isEmpty()) {
            return null;
        }

        return UserCRUD.readByEmailAndPassword(email, password);
    }

    public static boolean isAuthenticated(String email, String password) {
        return login(email, password) != null;
    }

    public static String loginAndCreateToken(String email, String password) {
        UserInfo user = login(email, password);

        if (user == null) {
            return null;
        }

        return JWTUtil.generateToken(user);
    }
}