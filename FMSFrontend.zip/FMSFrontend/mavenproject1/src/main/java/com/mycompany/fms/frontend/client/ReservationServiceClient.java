package com.mycompany.fms.frontend.client;

import com.mycompany.fms.frontend.helper.ReservationInfo;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ReservationServiceClient {

    private ReservationServiceClient() {
    }

    private static String getBaseUrl() {
        String serviceHost = System.getenv("RESERVATION_SERVICE_HOST");
        if (serviceHost == null || serviceHost.trim().isEmpty()) {
            serviceHost = "localhost:8080";
        }

        return "http://" + serviceHost + "/ReservationService/webresources/reservations";
    }

    public static ReservationInfo reserveFlight(int flightId, int userId) throws Exception {

        HttpURLConnection connection = null;
        InputStream inputStream = null;
        OutputStream outputStream = null;

        try {
            URL url = new URL(getBaseUrl() + "/create");
            connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/xml");
            connection.setRequestProperty("Accept", "application/xml");

            String requestXml =
                    "<reservation>" +
                            "<flightId>" + flightId + "</flightId>" +
                            "<userId>" + userId + "</userId>" +
                    "</reservation>";

            outputStream = connection.getOutputStream();
            outputStream.write(requestXml.getBytes("UTF-8"));
            outputStream.flush();

            int responseCode = connection.getResponseCode();

            if (responseCode != HttpURLConnection.HTTP_OK &&
                responseCode != HttpURLConnection.HTTP_CREATED) {
                String error = readErrorResponse(connection);
                throw new Exception("Reservation service failed. HTTP " + responseCode + " - " + error);
            }

            inputStream = connection.getInputStream();
            return parseReservationXml(inputStream);

        } finally {
            if (outputStream != null) outputStream.close();
            if (inputStream != null) inputStream.close();
            if (connection != null) connection.disconnect();
        }
    }

    private static String readErrorResponse(HttpURLConnection connection) {
        try {
            InputStream errorStream = connection.getErrorStream();
            if (errorStream == null) return "No error details";

            BufferedReader reader = new BufferedReader(new InputStreamReader(errorStream));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            reader.close();
            return sb.toString();

        } catch (Exception e) {
            return "Unable to read error response";
        }
    }

    private static ReservationInfo parseReservationXml(InputStream inputStream) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(inputStream);

        document.getDocumentElement().normalize();

        Element root = document.getDocumentElement();
        if (root != null && "reservation".equalsIgnoreCase(root.getTagName())) {
            return buildReservationFromElement(root);
        }

        NodeList reservationNodes = document.getElementsByTagName("reservation");
        if (reservationNodes.getLength() > 0) {
            Element element = (Element) reservationNodes.item(0);
            return buildReservationFromElement(element);
        }

        return null;
    }

    private static ReservationInfo buildReservationFromElement(Element element) {
        ReservationInfo reservation = new ReservationInfo();

        reservation.setReservationId(parseInt(getTagValue(element, "reservationId")));
        reservation.setFlightId(parseInt(getTagValue(element, "flightId")));
        reservation.setUserId(parseInt(getTagValue(element, "userId")));
        reservation.setConfirmationStatus(getTagValue(element, "confirmationStatus"));
        reservation.setPaymentStatus(getTagValue(element, "paymentStatus"));

        return reservation;
    }

    private static String getTagValue(Element parent, String tagName) {
        NodeList nodeList = parent.getElementsByTagName(tagName);

        if (nodeList == null || nodeList.getLength() == 0) {
            return "";
        }

        Node node = nodeList.item(0);
        if (node == null) {
            return "";
        }

        return node.getTextContent() != null ? node.getTextContent().trim() : "";
    }

    private static int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }
}